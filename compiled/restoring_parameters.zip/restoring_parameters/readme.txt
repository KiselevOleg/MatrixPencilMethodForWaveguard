a program for restoring parameters from a dispersion curves points and layers parameters

input_dispersion_curvespoints_path.txt

	file with dispersion curves points(must has structure like an exapmle)

file with dispersion curves points (note that imag parts are not used and should be near 0)

	number of points
	f_of_points_1 real_value_of_point_1 imag_value_of_point_1
	f_of_points_2 real_value_of_point_2 imag_value_of_point_2
	f_of_points_3 real_value_of_point_3 imag_value_of_point_3
	...

layer_parameters.txt (note that restoring parameters values are not used(values at restoring_parameters.txt are used))

	number_of_layers
	
	h_for_layer_1
	rho_for_layer_1
	Cp_for_layer_1
	Cs_for_layer_1

	h_for_layer_2
	rho_for_layer_2
	Cp_for_layer_2
	Cs_for_layer_2
	...

restoring_dparameters.txt

	number_of_restoring_parameters
	
	number_of_layer_for_parameter_1
	name_of_layer_parameter_for_parameter_1
	min_value_for_parameter_1
	difference_value_for_parameter_1
	max_value_for_parameter_1
	
	number_of_layer_for_parameter_2
	name_of_layer_parameter_for_parameter_2
	min_value_for_parameter_2
	difference_value_for_parameter_2
	max_value_for_parameter_2
	...

result_path.txt

	file_for_write_result
