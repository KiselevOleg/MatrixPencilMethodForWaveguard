a program for creating a theoretical dispersion curves

input files

layer_parameters.txt

	number_of_layers

	h_for_layer_1
	rho_for_layer_1
	Cp_for_layer_1
	Cs_for_layer_1
	
	h_for_layer_2
	rho_for_layer_2
	Cp_for_layer_2
	Cs_for_layer_2
	
	h_for_layer_3
	rho_for_layer_3
	Cp_for_layer_3
	Cs_for_layer_3
	...

omega.txt

	start_omega_value
	domega_value
	end_onega_value

result has dispersion curves points for omega in {start_omega, start_omega+domega, start_omega+2*domega, ..., until < end_omega}

result_path.txt

	path_to_file_for_write_result

result file

	omega_value_1 dispersion_curve_value_1
	omega_value_1 dispersion_curve_value_2
	...
	omega_value_1 dispersion_curve_value_3
	omega_value_2 dispersion_curve_value_4
	omega_value_2 dispersion_curve_value_5
	...
	omega_value_2 dispersion_curve_value_6
	...
